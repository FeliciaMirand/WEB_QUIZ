document.getElementById('checkResult').addEventListener('click', function() {
    
    const correctAnswers = {
        1: 'certa',
        2: 'certa',
        3: 'certa',
        4: 'certa',
        5: 'certa',
        6: 'certa',
        7: 'certa',
        8: 'certa',
        9: 'certa',
        10: 'certa'
    };

    let score = 0;
    const totalQuestions = Object.keys(correctAnswers).length;

    // Verifica cada questão
    for (let i = 1; i <= totalQuestions; i++) {
        const selectedOption = document.querySelector(`input[name="resposta"]:checked`);
        if (selectedOption && selectedOption.value === correctAnswers[i]) {
            score++;
        }
    }

    if (score === 0) {
        alert("Você não acertou nenhuma questão.");
        setTimeout(function() {
            window.location.href = 'nenhuma.html';
        }, 5000);
    } 
    
    else if (score > 0 && score <= 5) {
        alert(`Você acertou ${score} de ${totalQuestions} questões. Continue praticando!`);
        setTimeout(function() {
            window.location.href = 'parcial.html';
        }, 5000);
    } 

    else if (score >= 6 && score <= 9) {
        alert(`Você acertou ${score} de ${totalQuestions} questões! Bom trabalho!`);
        setTimeout(function() {
            window.location.href = 'quase_sucesso.html';
        }, 5000);
    } 

    else if (score === totalQuestions) {
        alert("Você acertou todas as questões!");
        setTimeout(function() {
            window.location.href = 'todas.html';
        }, 5000);
    }
});